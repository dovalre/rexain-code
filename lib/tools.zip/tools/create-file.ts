import { tool } from 'ai';
import { z } from 'zod';
import { Sandbox } from '@vercel/sandbox';

const createFileSchema = z.object({
  path: z
    .string()
    .describe('Workspace-relative path to the file to create (e.g., "src/index.ts")'),
  content: z
    .string()
    .describe('The content to write to the file'),
  sandboxName: z
    .string()
    .describe('The name of the sandbox to create the file in (e.g., "sbx_xxx")'),
});

export const createFileTool = tool({
  description: `Create a file inside the sandbox.

  USAGE:
  - Creates or replaces a file at the specified path
  - Supports any file type (source code, config, markdown, JSON, etc.)
  - Uses workspace-relative paths

  EXAMPLES:
  - path: "src/index.ts", content: "console.log('hello')"
  - path: "package.json", content: "{...}"
  - path: "README.md", content: "# My Project"`,
  inputSchema: createFileSchema,
  execute: async ({ path, content, sandboxName }: z.infer<typeof createFileSchema>) => {
    try {
      const sandbox = await Sandbox.get({
        name: sandboxName,
      });

      await sandbox.writeFiles([
        {
          path,
          content: Buffer.from(content),
        },
      ]);

      return {
        success: true,
        path: path,
        message: `Successfully created file at ${path}`,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        error: `Failed to create file: ${message}`,
      };
    }
  },
});