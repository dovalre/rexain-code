import { tool } from 'ai';
import { z } from 'zod';
import { Sandbox } from '@vercel/sandbox';

const createSandboxSchema = z.object({
  runtime: z
    .enum(['node24', 'node22', 'node26', 'python3.13'])
    .optional()
    .default('node24')
    .describe('Runtime for the sandbox (node24, node22, node26, or python3.13)'),
  ports: z
    .array(z.number())
    .optional()
    .describe('Ports to expose from the sandbox (up to 4 ports)'),
  env: z
    .record(z.string(), z.string())
    .optional()
    .describe('Environment variables to set in the sandbox'),
  timeout: z
    .number()
    .optional()
    .describe('Timeout in milliseconds before sandbox auto-terminates'),
});

export const createSandboxTool = tool({
  description: `Create a new sandbox instance for running code.

  USAGE:
  - Creates a fresh isolated sandbox with the specified runtime
  - Runtimes: node24 (default), node22, node26, python3.13
  - Can expose ports and set environment variables
  - Returns sandbox configuration details

  IMPORTANT:
  - Each sandbox is isolated and temporary
  - Sandboxes can be managed using Vercel Sandbox APIs
  - Maximum 4 ports can be exposed
  - Use the appropriate runtime for your workload

  EXAMPLES:
  - Create a Node.js sandbox: runtime: "node24"
  - Create a Python sandbox: runtime: "python3.13"
  - Create with ports and env:
    runtime: "node24",
    ports: [3000, 5000],
    env: { "API_KEY": "secret" }`,
  inputSchema: createSandboxSchema,
  execute: async ({ runtime = 'node24', ports = [3000], env = {}, timeout = 600000 }: z.infer<typeof createSandboxSchema>) => {
    try {
      // Create sandbox with specified runtime and configuration
      const sandbox = await Sandbox.create({
        runtime,
        ports,
        env,
        timeout,
      });

       const sandboxName = sandbox.name;

      return {
        success: true,
        runtime,
        ports,
        sandboxName,
        message: `Successfully created ${runtime} sandbox`,
        timeout,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        error: `Failed to create sandbox: ${message}`,
      };
    }
  },
});
