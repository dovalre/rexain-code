import { tool } from 'ai';
import { z } from 'zod';
import { Sandbox } from '@vercel/sandbox';

const runCommandSchema = z.object({
  command: z
    .string()
    .describe(
      "The base command to run (e.g., 'npm', 'node', 'python', 'ls', 'cat'). Do NOT include arguments here."
    ),
  args: z
    .array(z.string())
    .optional()
    .describe(
      'Array of arguments for the command. Each argument should be a separate string (e.g., ["install", "--verbose"])'
    ),
  sudo: z
    .boolean()
    .optional()
    .default(false)
    .describe('Whether to run the command with sudo (default: false)'),
  detached: z
    .boolean()
    .optional()
    .default(false)
    .describe('Run command in background'),
  sandboxName: z
    .string()
    .describe('The name of the sandbox to read the file from (e.g., "sbx_xxx")'),
});

export const runCommandTool = tool({
  description: `Execute a command inside a sandbox.

  USAGE:
  - Base command: npm, node, python, ls, cat, mkdir, etc.
  - Arguments passed as separate array items
  - Supports background execution with detached=true
  - Supports sudo execution

  EXAMPLES:
  - command: "npm", args: ["install"]
  - command: "npm", args: ["run", "dev"], detached: true
  - command: "node", args: ["index.js"]
  - command: "ls", args: ["-la"]`,
  inputSchema: runCommandSchema,
  execute: async ({ command, args = [], sudo, detached, sandboxName }: z.infer<typeof runCommandSchema>) => {
    try {
      const sandbox = await Sandbox.get({ name: sandboxName });

      const result = await sandbox.runCommand({
        cmd: command,
        args,
        sudo,
        detached,
      });

      if (detached) {
        return {
          success: true,
          command,
          args,
          cmdId: result.cmdId,
          message: 'Command started in background',
        };
      }

      return {
        success: result.exitCode === 0,
        command,
        args,
        exitCode: result.exitCode,
        stdout: await result.stdout(),
        stderr: await result.stderr(),
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      return {
        success: false,
        error: `Failed to execute command: ${message}`,
      };
    }
  },
});